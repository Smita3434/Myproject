﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Myproject
{
    class Rectangle
    {
        static void Main(string[] args)
        {
            int length = 4, breadth = 7, area;
            area = length * breadth;
            Console.WriteLine("area of Rectangle=" +area);
                
        }
    }
}
