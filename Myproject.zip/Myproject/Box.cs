﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Myproject
{
   /* class Box
    {
        int l, h, w;
        int result;
        int area;

        static void Main(string[] args)
        {
            Box cube = new Box();

            cube.area=cube.l=cube.h=cube.w;
                Console.WriteLine("Enter the area:");
            cube.area = Convert.ToInt32(Console.ReadLine());
            
            cube.result = 6 * cube.area * cube.area;

            Console.WriteLine(cube.result);
        }
    }*/
}
