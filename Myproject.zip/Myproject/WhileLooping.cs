﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Myproject
{
    class WhileLooping
    {
        static void Main(string[] args)
        {
            int i = 1;
            while (i <= 5)
            {
                Console.WriteLine(i);
                i++;
            }
        }
      
    }
        
}
