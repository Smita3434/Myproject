﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Myproject.Array
{
    class ArrayDemo
    {
        static void Main(string[] args)
        {
            int[] marks = {34,12,67,3,4 };

            int[] a = new int[4];
            a[0] = 33;
            a[1] = 2;
            a[2] = 89;
            a[3] = 14;

            Console.WriteLine("Enter array Element:");
 
        }
    }
}
