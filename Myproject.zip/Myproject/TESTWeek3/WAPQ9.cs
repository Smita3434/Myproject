﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Myproject.TESTWeek3
{
    class WAPQ9
    {
        static void Main(string[] args)
        {
            int[,] arr = new int[,] { { 1, 2, 3, 4 }, { 5, 6, 7, 8 } };

           // Array.Revers(arr);

            Console.WriteLine(string.Join(' ', arr));
        }
    }
}
