﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Myproject.TESTWeek3
{
    class WAPQ7
    {
        /*public class ArrayOutput
        {
            public static void Main(String[] args)
            {
                int[] a1= {1,2,3};
                int a2;

                a2 = new String[a1.Length];
                for(int i=0;i<a1.Length;i++)
                {
                    a2[i] = a1[i];
                }
                for(int i=0;i<a2.Length();i++)
                {
                    Console.WriteLine(a2[i]);
                }
                
            }
        }*/
    }
}
