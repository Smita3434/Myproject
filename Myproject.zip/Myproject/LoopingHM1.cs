﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Myproject
{
    class LoopingHM1
    {
        static void Main(string[] args)
        {

            for(int i=0;i<=10;i++)
            {
                Console.WriteLine(i);
            }
        }
    }
}
