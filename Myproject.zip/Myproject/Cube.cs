﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Myproject
{
    class Cube
    {
        static void Main(string[] args)
        {
            int c ,n;
            c = 5;
            n = c * c * c;
            Console.WriteLine("cube=" +n);
        }
    }
}
