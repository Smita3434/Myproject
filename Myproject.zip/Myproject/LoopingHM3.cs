﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Myproject
{
    class LoopingHM3
    {
        static void Main(string[] args)
        {
            for(int i=75;i>=25;i--)
            {
                Console.WriteLine(i);
            }
        }
    }
}
