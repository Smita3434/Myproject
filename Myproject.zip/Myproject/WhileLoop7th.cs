﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Myproject
{
    class WhileLoop7th
    {
        static void Main(string[] args)
        {
            Console.WriteLine(1);
            int i = 1;
            while(i<=50)
            {
               
                i =i+6;
            }
            Console.WriteLine(i);
        }
    }
}
