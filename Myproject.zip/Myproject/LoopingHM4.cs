﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Myproject
{
    class LoopingHM4
    {
        static void Main(string[] args)
        {
            for(int j=325;j<=400;j++)
            {
                Console.WriteLine(j);
            }
        }
    }
}
