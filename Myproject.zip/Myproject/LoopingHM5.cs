﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Myproject
{
    class LoopingHM5
    {
        static void Main(string[] args)
        {
            for(int k=300;k>=175;k--)
            {
                Console.WriteLine(k);
            }
        }
    }
}
