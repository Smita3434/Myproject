﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Myproject
{
    class LoopingHM2
    {
        static void Main(string[] args)
        {
            for(int i=25;i<=50;i++)
            {
                Console.WriteLine(i);
            }
        }
    }
}
